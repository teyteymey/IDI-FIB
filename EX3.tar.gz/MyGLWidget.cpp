// MyGLWidget.cpp
#include "MyGLWidget.h"
#include <iostream>
#include <stdio.h>

#define printOpenGLError() printOglError(__FILE__, __LINE__)
#define CHECK() printOglError(__FILE__, __LINE__,__FUNCTION__)
#define DEBUG() std::cout << __FILE__ << " " << __LINE__ << " " << __FUNCTION__ << std::endl;

int MyGLWidget::printOglError(const char file[], int line, const char func[]) 
{
    GLenum glErr;
    int    retCode = 0;

    glErr = glGetError();
    const char * error = 0;
    switch (glErr)
    {
        case 0x0500:
            error = "GL_INVALID_ENUM";
            break;
        case 0x501:
            error = "GL_INVALID_VALUE";
            break;
        case 0x502: 
            error = "GL_INVALID_OPERATION";
            break;
        case 0x503:
            error = "GL_STACK_OVERFLOW";
            break;
        case 0x504:
            error = "GL_STACK_UNDERFLOW";
            break;
        case 0x505:
            error = "GL_OUT_OF_MEMORY";
            break;
        default:
            error = "unknown error!";
    }
    if (glErr != GL_NO_ERROR)
    {
        printf("glError in file %s @ line %d: %s function: %s\n", file, line, error, func);
        retCode = 1;
    }
    return retCode;
}

MyGLWidget::~MyGLWidget() {
}

void MyGLWidget::ini_camera(){
	//ini projectTransform variables
	float FOV = float(M_PI)/2.0f;
	float window = 1.0f;
	float znear = 0.4f;
	float zfar = 3.0f;
	projectTransform(FOV, window , znear, zfar);
	
	//ini viewTransform variables
	glm::vec3 obs (0,0,1);
	glm::vec3 vrp (0,0,0);
	glm::vec3 up (1,0,0);
	viewTransform(obs, vrp, up);
}

void MyGLWidget::paintGL(){
	Bl2GLWidget::paintGL();
	ini_camera();
}

void MyGLWidget::projectTransform (float FOV, float window , float znear, float zfar) {
	// glm::perspective (FOV en radians , ra window , znear, zfar)
	glm::mat4 Proj = glm::perspective(FOV, window , znear, zfar);
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, &Proj[0][0]);
}

void MyGLWidget::viewTransform(glm::vec3 obs, glm::vec3 vrp, glm::vec3 up){
	// obs, vrp, up
	glm::mat4 View = glm::lookAt(obs, vrp, up);
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, &View[0][0]);
}

void MyGLWidget::carregaShaders() {
	Bl2GLWidget::carregaShaders(); // cridem primer al mètode de Bl2GLWidget
	projLoc = glGetUniformLocation(program->programId(), "proj");
	viewLoc = glGetUniformLocation(program->programId(), "view");
}




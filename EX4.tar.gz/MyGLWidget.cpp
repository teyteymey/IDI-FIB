// MyGLWidget.cpp
#include "MyGLWidget.h"
#include <iostream>
#include <stdio.h>

#define printOpenGLError() printOglError(__FILE__, __LINE__)
#define CHECK() printOglError(__FILE__, __LINE__,__FUNCTION__)
#define DEBUG() std::cout << __FILE__ << " " << __LINE__ << " " << __FUNCTION__ << std::endl;

int MyGLWidget::printOglError(const char file[], int line, const char func[]) 
{
    GLenum glErr;
    int    retCode = 0;

    glErr = glGetError();
    const char * error = 0;
    switch (glErr)
    {
        case 0x0500:
            error = "GL_INVALID_ENUM";
            break;
        case 0x501:
            error = "GL_INVALID_VALUE";
            break;
        case 0x502: 
            error = "GL_INVALID_OPERATION";
            break;
        case 0x503:
            error = "GL_STACK_OVERFLOW";
            break;
        case 0x504:
            error = "GL_STACK_UNDERFLOW";
            break;
        case 0x505:
            error = "GL_OUT_OF_MEMORY";
            break;
        default:
            error = "unknown error!";
    }
    if (glErr != GL_NO_ERROR)
    {
        printf("glError in file %s @ line %d: %s function: %s\n", file, line, error, func);
        retCode = 1;
    }
    return retCode;
}

MyGLWidget::~MyGLWidget() {
}

void MyGLWidget::ini_camera(){
	//ini projectTransform variables
	float FOV = float(M_PI)/2.0f;
	float window = 1.0f;
	float znear = 0.4f;
	float zfar = 3.0f;
	projectTransform(FOV, window , znear, zfar);
	
	//ini viewTransform variables
	glm::vec3 obs (0,0,1);
	glm::vec3 vrp (0,0,0);
	glm::vec3 up (0,1,0);
	viewTransform(obs, vrp, up);
}

void MyGLWidget::initializeGL(){
	Bl2GLWidget::initializeGL();
	
	// Activate z-buffer
	glEnable (GL_DEPTH_TEST);
	// Delete depth and frame buffer
	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	m.load ("./models/HomerProves.obj");
	creaBuffersHomer();
	
	ini_camera();
	modelTransform();
}

void MyGLWidget::paintGL(){
	//Bl2GLWidget::paintGL();
	
	// Load VAO
	glBindVertexArray (VAO_Homer);

	// Draw Object
	glDrawArrays(GL_TRIANGLES, 0, m.faces().size()*3);
	
	glBindVertexArray (0);
	
}

void MyGLWidget::creaBuffersHomer(){

	// Creation of VAO containing data of Object
	glGenVertexArrays(1, &VAO_Homer);
	glBindVertexArray(VAO_Homer);

	// Creation of VBO
	glGenBuffers(2, VBO_Homer);
	
	// Place vertices of triangles in the first VBO
	glBindBuffer(GL_ARRAY_BUFFER, VBO_Homer[0]);
	int numberB_VBO = sizeof(GLfloat) * m.faces ().size () * 3 * 3; // number of bytes of Buffers
	glBufferData(GL_ARRAY_BUFFER, numberB_VBO, m.VBO_vertices(), GL_STATIC_DRAW);
	
	// Send location to vertexShader
	glVertexAttribPointer(vertexLoc, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(vertexLoc);
	
	// Place colors of triangles in the second VBO
	glBindBuffer(GL_ARRAY_BUFFER, VBO_Homer[1]);
	glBufferData(GL_ARRAY_BUFFER, numberB_VBO, m.VBO_matdiff(), GL_STATIC_DRAW);

	// Send color to vertexShader
	glVertexAttribPointer(colorLoc, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(colorLoc);

}

void MyGLWidget::projectTransform (float FOV, float window , float znear, float zfar) {
	// glm::perspective (FOV en radians , ra window , znear, zfar)
	glm::mat4 Proj = glm::perspective(FOV, window , znear, zfar);
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, &Proj[0][0]);
}

void MyGLWidget::viewTransform(glm::vec3 obs, glm::vec3 vrp, glm::vec3 up){
	// obs, vrp, up
	glm::mat4 View = glm::lookAt(obs, vrp, up);
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, &View[0][0]);
}

/*
* I am gonna try to place the model in the origin
*/
void MyGLWidget::modelTransform (){
	glm::mat4 transform(1.0);	// Start with identity matrix
	transform = glm::translate(transform, glm::vec3(0.0,0.0,0.0));	// Translate to the origin
	transform = glm::scale(transform, glm::vec3(0.7,0.7,0.7));	// Scale it so it fits in the window
	glUniformMatrix4fv(transLoc, 1, GL_FALSE, &transform[0][0]);
}

void MyGLWidget::carregaShaders() {
	Bl2GLWidget::carregaShaders(); // cridem primer al mètode de Bl2GLWidget
	
	projLoc = glGetUniformLocation(program->programId(), "proj");
	viewLoc = glGetUniformLocation(program->programId(), "view");
	transLoc = glGetUniformLocation(program->programId(), "TG");
	
	vertexLoc = glGetAttribLocation (program->programId(), "vertex");
	colorLoc = glGetAttribLocation (program->programId(), "color");
}




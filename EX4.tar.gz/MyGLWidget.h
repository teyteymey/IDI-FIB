// MyGLWidget.h
#include "Bl2GLWidget.h"
#include "Model/model.h"

class MyGLWidget : public Bl2GLWidget {
	Q_OBJECT

	public:
	MyGLWidget(QWidget *parent=0) : Bl2GLWidget(parent) {}
	~MyGLWidget();

	private:
	int printOglError(const char file[], int line, const char func[]);
	void carregaShaders();
	void projectTransform(float FOV, float window , float znear, float zfar);
	void viewTransform(glm::vec3 obs, glm::vec3 vrp, glm::vec3 up);
	void paintGL();
	void ini_camera();
	void creaBuffersHomer();
	void initializeGL();
	void modelTransform();

	// Uniform locations
	GLuint projLoc, viewLoc;
	
	// Attributes
	GLuint vertexLoc, colorLoc;
	
	// Transformations
	GLuint transLoc;
	    
	// Data and Buffer Arrays
	GLuint VAO_Homer;
	GLuint VBO_Homer[2];
	
	// Creation of a model object
	Model m;
    
};
